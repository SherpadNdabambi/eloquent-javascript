// load dependencies
require("./code/load")("code/mountains.js", "code/chapter/06_object.js");

console.log(drawTable(dataTable(MOUNTAINS)));
